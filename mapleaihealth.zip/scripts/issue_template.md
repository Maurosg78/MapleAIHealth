# [Sprint X] Título de la Tarea

## Descripción
Breve descripción de la tarea o issue

## Objetivos
- [ ] Objetivo 1
- [ ] Objetivo 2
- [ ] Objetivo 3

## Criterios de Aceptación
- [ ] Criterio 1
- [ ] Criterio 2
- [ ] Criterio 3

## Recursos Adicionales
- Enlaces a documentación relevante
- Mockups o diseños relacionados
- Referencias a issues relacionados

## Notas
Cualquier información adicional que pueda ser útil

## Estimación
Estimación de tiempo para completar la tarea: X días/horas 