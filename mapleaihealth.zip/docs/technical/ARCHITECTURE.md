# Arquitectura del Sistema

## Visión General
Sistema modular basado en React con servicios de IA integrados.

## Componentes Principales
- Frontend (React + TypeScript)
- Servicios de IA
- Gestión de Datos
- API REST

## Integración con IA
Detalles de la integración con servicios de IA...
