/**
 * Índice de módulos de referencias para fisioterapia española
 * Facilita la importación de todos los módulos relacionados
 */

export * from './fisioterapiaValenciana';
export * from './ejerciciosTerapeuticos'; 