declare module '@heroicons/react/outline';
declare module '@heroicons/react/solid';
declare module '@heroicons/react/24/outline';
declare module '@heroicons/react/24/solid'; 