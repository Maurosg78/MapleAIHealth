// Exportaciones para el módulo de IA clínica
export { SmartSuggestionPanel } from './SmartSuggestionPanel';
export { ClinicalAssistant } from './ClinicalAssistant'; 