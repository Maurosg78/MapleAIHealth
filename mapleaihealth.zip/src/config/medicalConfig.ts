import { config } from './config';;;;;

export const medicalConfig = config.medical; 